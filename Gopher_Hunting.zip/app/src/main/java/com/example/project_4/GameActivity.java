package com.example.project_4;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import java.util.Random;


public class GameActivity extends AppCompatActivity {
    /* LinearLayout (with Scrollable in XML to make the layout scrollable if needed) */
    LinearLayout game_layout;

    /* TableLayouts to dynamically add the 2 progress tables */
    TableLayout player1_table, player2_table;

    /* TextViews for both players to display the game status upon a change */
    TextView player1_text, player2_text;

    /* Stop/Back Button */
    Button stop_button;

    /* Tag to store gopher location */
    int gopher;

    /* Flag to check if game is stopped/completed to avoid sending unnecessary messages to handlers */
    boolean game_done = false;

    /* int values for feedback and messages */
    public static final int SUCCESS = 0;
    public static final int NEAR_MISS = 1;
    public static final int CLOSE_GUESS = 2;
    public static final int COMPLETE_MISS = 3;
    public static final int STOP_GAME = 4;
    public static final int DISPLAY_WINNER = 5;

    /* Handlers for the player threads */
    private Handler Player1Handler;
    private Handler Player2Handler;

    /* Player thread instances - t1 is PLayer 1 and t2 is Player 2*/
    Thread t1, t2;


    /* UI thread handler */
    private final Handler mHandler = new Handler(Looper.getMainLooper()){
        /* Handle any messages sent to the UI thread */
        public void handleMessage(Message msg){
            /* Extract the components of the received message */
            int what = msg.what;
            int winner = msg.arg1;

            /* Case to display winner - Sent from the winner thread to the UI thread */
            if (what == DISPLAY_WINNER) {
                /* When Player 1 wins the game */
                /* Change Player 1's text string to indicate winning status */
                if (winner == 1) {
                    player1_text.setText(getString(R.string.p1_winner));
                    player1_text.setTextColor(getResources().getColor(R.color.green));
                    player1_text.setTypeface(player1_text.getTypeface(), Typeface.BOLD);
                }

                /* When Player 2 wins the game */
                /* Change Player 2's text string to indicate winning status */
                else {
                    player2_text.setText(getString(R.string.p2_winner));
                    player2_text.setTextColor(getResources().getColor(R.color.green));
                    player2_text.setTypeface(player2_text.getTypeface(), Typeface.BOLD);
                }

                /* Change the Stop button to Back Button */
                stop_button.setText(getString(R.string.back));
            }
        }
    };


    /* onCreate */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        /* Get the Linear Layout view by ID */
        game_layout = findViewById(R.id.gameLayout);

        /* Linear Layout structure - Built programmatically */
        /* Player 1 Text */
        player1_text = new TextView(this);
        generateTextView(player1_text, game_layout, getString(R.string.player_1));

        /* Player 1 Field Table */
        player1_table = new TableLayout(this);
        generateTable(player1_table, game_layout, "1");

        /* Player 2 Text */
        player2_text = new TextView(this);
        generateTextView(player2_text, game_layout, getString(R.string.player_2));

        /* Player 2 Field Table */
        player2_table = new TableLayout(this);
        generateTable(player2_table, game_layout, "2");

        /* Stop/Back Button */
        stop_button = new Button(this);
        generateButton(stop_button, game_layout, getString(R.string.stop));
        /* End of Linear Layout structure */

        /* Use the button view to set up a listener for the OnClick event */
        stop_button.setOnClickListener(v -> stopGame());

        /* Generate a random number between 0 and 100 to assign as the position of the gopher in the fields */
        Random rand = new Random();
        gopher = rand.nextInt(100);

        /* Assign gopher (marked with "G") to its position in Player 1's table */
        setCellText(gopher + 100, "G");

        /* Assign gopher (marked with "G") to its position in Player 2's table */
        setCellText(gopher + 200, "G");

        /* Create and start Player 1's thread */
        t1 = new Thread(new Player1Runnable()) ;
        t1.start();

        /* Create and start Player 2's thread */
        t2 = new Thread(new Player2Runnable()) ;
        t2.start();
    }


    /* Player 1 thread */
    public class Player1Runnable implements Runnable {
        /* Random number generator */
        Random rand = new Random();

        /* Array to store the state of guesses - To prevent guessing of already guessed positions */
        int[] guesses_1 = new int[100];

        /* Counter for guesses */
        int i = 1;

        /* Offset for Player 1 - 100 since Player 1's table's tags lie between 100 and 199 (inclusive) */
        int offset = 100;

        /* Generate the first guess using the random number generator */
        int tag = rand.nextInt(100) + offset;

        /* Store previous guess */
        int prev_1 =  tag;


        public void run() {
            /* Prepare looper for Player 1 */
            Looper.prepare();

            /* Post the first guess to the UI thread's handler for feedback */
            mHandler.post(new Runnable() {
                public void run() {
                    sendFeedback(tag, offset, guesses_1, i, Player1Handler);
                }
            } );


            /* Player 1 thread handler */
            Player1Handler = new Handler(Looper.myLooper()) {
                /* Handle any messages sent to the Player 1 thread */
                public void handleMessage(Message msg) {
                    /* Extract the components of the received message */
                    int what = msg.what;

                    /* Store previous guess */
                    prev_1 = tag;

                    /* Put the thread to sleep for 2 seconds - Mimics the thread making a guess */
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    /* Handle messages based on their content */
                    switch (what) {
                        /* Player 1 found the gopher */
                        case SUCCESS:
                            /* Print winner on console - for testing */
                            System.out.println("Player 1 Winner");

                            /* Create message to send to UI thread to display Player 1 as the winner */
                            Message winner_msg = mHandler.obtainMessage(DISPLAY_WINNER);

                            /* Set Player 1 as the winner */
                            winner_msg.arg1 = 1;

                            /* Send message to the UI thread */
                            mHandler.sendMessage(winner_msg);

                            break;

                        /* Near Miss and Close Guess handled in the same manner */
                        /* The algorithm makes a smart guess based on the message content received as feedback from the UI thread */

                        /* Player 1 is within a 2 hole distance from the gopher */
                        case NEAR_MISS:

                        /* Player 1 is within a 1 hole distance from the gopher */
                        case CLOSE_GUESS:
                            /* Keep generating guesses until a previously unused tag is selected */
                            while (guesses_1[tag - offset] == 1) {
                                /* Use the algorithm to make a smart guess based on the feedback */
                                tag = smartGuess(prev_1, what, offset);

                                /* Print current and previous guess on console - for testing */
                                System.out.println("Player 1: Previous:" + prev_1 + ", Current: " + tag);
                            }

                            break;

                        /* Player 1 is not close to the gopher */
                        case COMPLETE_MISS:
                            /* Keep generating guesses until a previously unused tag is selected */
                            while (guesses_1[tag - offset] == 1) {
                                /* Generate a random tag */
                                tag = rand.nextInt(100) + offset;

                                /* Print current and previous guess on console - for testing */
                                System.out.println("Player 1: Previous:" + prev_1 + ", Current: " + tag);
                            }

                            break;

                        /* Stop the game - Sent from UI thread when the Stop button is clicked */
                        case STOP_GAME:
                            /* Quit the looper */
                            Looper.myLooper().quit();
                    }

                    /* Increase the guess number */
                    i ++;

                    /* Check if game is in progress */
                    if(!game_done) {
                        /* Post the guess to the UI thread for feedback */
                        mHandler.post(new Runnable() {
                            public void run() {
                                sendFeedback(tag, offset, guesses_1, i, Player1Handler);
                            }
                        });
                    }
                }
            };

            /* Loop the looper */
            Looper.loop();
        }
    }


    /* Player 2 thread */
    public class Player2Runnable implements Runnable {
        /* Random number generator */
        Random rand = new Random();

        /* Array to store the state of guesses - To prevent guessing of already guessed positions */
        int[] guesses_2 = new int[100];

        /* Counter for guesses */
        int i = 1;

        /* Offset for Player 2 - 200 since Player 2's table's tags lie between 200 and 299 (inclusive) */
        int offset = 200;

        /* Generate the first guess using the random number generator */
        int tag = rand.nextInt(100) + offset;

        /* Store previous guess */
        int prev_2 =  tag;


        public void run() {
            /* Prepare looper for Player 2 */
            Looper.prepare();

            /* Post the first guess to the UI thread's handler for feedback */
            mHandler.post(new Runnable() {
                public void run() {
                    sendFeedback(tag, offset, guesses_2, i, Player2Handler);
                }
            });


            /* Player 2 thread handler */
            Player2Handler = new Handler(Looper.myLooper()) {
                /* Handle any messages sent to the Player 2 thread */
                public void handleMessage(Message msg) {
                    /* Extract the components of the received message */
                    int what = msg.what;

                    /* Store previous guess */
                    prev_2 = tag;

                    /* Put the thread to sleep for 2 seconds - Mimics the thread making a guess */
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    /* Handle messages based on their content */
                    switch (what) {
                        /* Player 2 found the gopher */
                        case SUCCESS:
                            /* Print winner on console - for testing */
                            System.out.println("Player 2 Winner");

                            /* Create message to send to UI thread to display Player 2 as the winner */
                            Message winner_msg = mHandler.obtainMessage(DISPLAY_WINNER);

                            /* Set Player 2 as the winner */
                            winner_msg.arg1 = 2;

                            /* Send the message to the UI thread */
                            mHandler.sendMessage(winner_msg);

                            break;

                        /* Near Miss and Close Guess handled in the same manner */
                        /* The algorithm makes a smart guess based on the message content received as feedback from the UI thread */

                        /* Player 2 is within a 2 hole distance from the gopher */
                        case NEAR_MISS:

                        /* Player 2 is within a 1 hole distance from the gopher */
                        case CLOSE_GUESS:
                            /* Keep generating guesses until a previously unused tag is selected */
                            while (guesses_2[tag - offset] == 1) {
                                /* Use the algorithm to make a smart guess based on the feedback */
                                tag = smartGuess(prev_2, what, offset);

                                /* Print current and previous guess on console - for testing */
                                System.out.println("Player 2: Previous:" + prev_2 + ", Current: " + tag);
                            }

                            break;

                        /* Player 2 is not close to the gopher */
                        case COMPLETE_MISS:
                            /* Keep generating guesses until a previously unused tag is selected */
                            while (guesses_2[tag - offset] == 1) {
                                /* Generate a random tag */
                                tag =  rand.nextInt(100) + offset;

                                /* Print current and previous guess on console - for testing */
                                System.out.println("Player 2: Previous:" + prev_2 + ", Current: " + tag);
                            }

                            break;

                        /* Stop the game - Sent from UI thread when the Stop button is clicked */
                        case STOP_GAME:
                            /* Quit the looper */
                            Looper.myLooper().quit();
                    }

                    /* Increase the guess number */
                    i ++;

                    /* Check if game is in progress */
                    if(!game_done) {
                        /* Post the guess to the UI thread for feedback */
                        mHandler.post(new Runnable() {
                            public void run() {
                                sendFeedback(tag, offset, guesses_2, i, Player2Handler);
                            }
                        });
                    }
                }
            };

            /* Loop the looper */
            Looper.loop();
        }
    }


    /* Function to generate a TextView programmatically */
    private void generateTextView(TextView text_view, LinearLayout layout, String text) {
        /* Set the TextView's attributes */
        text_view.setText(text);
        text_view.setTextSize(20);
        text_view.setGravity(Gravity.CENTER_HORIZONTAL);

        /* Add the TextView to the Layout */
        layout.addView(text_view);

        /* Set additional layout based attributes */
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) text_view.getLayoutParams();
        params.setMargins(0, 30, 0,0);
        text_view.setLayoutParams(params);
    }


    /* Function to generate a 10 x 10 table programmatically */
    private void generateTable(TableLayout table, LinearLayout layout, String table_num) {
        int row, col, cell_tag;

        /* Loop over the rows of the table */
        for (row = 0; row < 10; row ++) {
            /* Generate a TableRow */
            TableRow table_row = new TableRow(this);

            /* Loop over the columns of the table */
            for(col = 0; col < 10; col ++) {
                /* Generate a TextView as a cell in the table */
                TextView table_cell = new TextView(this);

                /* Generate and set the cell tag based on the table, row and column numbers */
                cell_tag = Integer.parseInt(table_num + row + col);
                table_cell.setTag(cell_tag);

                /* Set the table cell's TextView's attributes */
                table_cell.setPadding(5, 5, 5, 5);
                table_cell.setTextSize(18);
                table_cell.setGravity(Gravity.CENTER_HORIZONTAL);
                table_cell.setMinimumWidth(90);

                /* Add a border to the table cell's TextView */
                table_cell.setBackground(AppCompatResources.getDrawable(this, R.drawable.cell_border));

                /* Add the table cell's TextView to the TableRow */
                table_row.addView(table_cell);
            }

            table_row.setMinimumHeight(50);
            table_row.setGravity(Gravity.CENTER_HORIZONTAL);

            /* Add the TableRow to the TableLayout */
            table.addView(table_row);
        }

        /* Add the table to the Layout */
        layout.addView(table);
    }


    /* Function to generate a Button programmatically */
    private void generateButton(Button button, LinearLayout layout, String text) {
        /* Set the Button's attributes */
        button.setText(text);
        button.setBackgroundColor(getResources().getColor(R.color.purple_500));
        button.setTextColor(getResources().getColor(R.color.white));

        /* Add the Button to the Layout */
        layout.addView(button);

        /* Set additional layout based attributes */
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) button.getLayoutParams();
        params.width = 230;
        params.height = 100;
        params.setMargins(0, 30, 0,30);
        params.gravity = Gravity.CENTER_HORIZONTAL;
        button.setLayoutParams(params);
    }


    /* Function to set the text of a cell in the table by using its tag - ALWAYS runs on the UI thread */
    private void setCellText(int tag, String text) {
        /* Get the TextView by ID */
        TextView textView = game_layout.findViewWithTag(tag);
        textView.setText(text);

        /* Styling TextView for the gopher's table cell - Light Purple cell color and Bold Italic "G" text */
        if (text.equals("G")) {
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD_ITALIC);
            textView.setBackground(AppCompatResources.getDrawable(this, R.drawable.gopher_border));
        }

        /* Styling TextView for the winner's table cell - Teal cell color and Bold Italic "W" text */
        if (text.equals("W")) {
            textView.setTypeface(textView.getTypeface(), Typeface.BOLD_ITALIC);
            textView.setBackground(AppCompatResources.getDrawable(this, R.drawable.winner_border));
        }

        /* Commented out code - for testing
        /*
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            System.out.println("On UI Thread: " + tag);
        } else {
            System.out.println("Not on UI Thread: " + tag);
        }
        */
    }


    /* Function to generate and send feedback based on the current guess - ALWAYS runs on the UI thread */
    private void sendFeedback(int tag, int offset, int [] guesses, int i, Handler hand) {
        /* Register the current tag as guessed */
        guesses[tag - offset] = 1;

        /* Calculate the distance of the current guess from the gopher */
        int[] diff = getDistance(gopher, tag, offset);

        /* Generate a message to send as feedback to the player thread that made the guess */
        Message msg = hand.obtainMessage();

        /* Distance is 0 - Gopher found - Success */
        if (diff[0] == 0 && diff[1] == 0){
            /* Set the feedback as Success */
            msg.what = SUCCESS;

            /* Set the TextView of the gopher as "W" - indicating winning guess */
            setCellText(tag, "W");

            /* Send the feedback to the player thread that made the guess */
            hand.sendMessage(msg);

            /* Set the game done flag to true */
            game_done = true;

            /* Post to the player threads to stop their looper - Using lambda notation */
            /* quitSafely() ensures that the SUCCESS message is handled */
            Player1Handler.post(() -> Looper.myLooper().quitSafely());
            Player2Handler.post(() -> Looper.myLooper().quitSafely());
        }

        /* Distance is within 1 hole of the gopher - Near Miss */
        else if (diff[0] <= 1 && diff[1] <= 1){
            /* Set the feedback as Near Miss */
            msg.what = NEAR_MISS;

            /* Set the TextView of the guessed cell as the guess number of that player */
            setCellText(tag, Integer.toString(i));

            /* Send the feedback to the player thread that made the guess */
            hand.sendMessage(msg);
        }

        /* Distance is within 2 holes of the gopher - Close Guess */
        else if (diff[0] <= 2 && diff[1] <= 2){
            /* Set the feedback as Close Guess */
            msg.what = CLOSE_GUESS;

            /* Set the TextView of the guessed cell as the guess number of that player */
            setCellText(tag, Integer.toString(i));

            /* Send the feedback to the player thread that made the guess */
            hand.sendMessage(msg);
        }

        /* Guess is not close to the gopher - Complete Miss */
        else{
            /* Set the feedback as Complete Miss */
            msg.what = COMPLETE_MISS;

            /* Set the TextView of the guessed cell as the guess number of that player */
            setCellText(tag, Integer.toString(i));

            /* Send the feedback to the player thread that made the guess */
            hand.sendMessage(msg);
        }
    }


    /* Function to generate a smart guess - ALWAYS runs on the worker thread */
    /* Uses an algorithm to generate a smart guess in case of a Near Miss or Close Guess, based on the feedback received */
    /* Handles both the cases by using the feedback */
    /* A smart guess is a guess made ONLY within a grid around the previous guess */
    /* Grid size and range depends on a "step" value: 1 for NEAR_MISS and 2 for CLOSE_GUESS (same int values as set initially) */
    private int smartGuess(int prev_guess, int feedback, int offset) {
        int step, guess, prev_row, prev_col, lower_bound_row, upper_bound_row, lower_bound_col, upper_bound_col, digit_1, digit_2;

        /* Random number generator */
        Random rand = new Random();

        /* Extract the row and column numbers from the previous guess */
        prev_guess = prev_guess - offset;
        prev_row = prev_guess / 10;
        prev_col = prev_guess % 10;

        /* Set the step value: 1 for NEAR_MISS and 2 for CLOSE_GUESS (same int values as set initially) */
        step = feedback;

        /* The standard grid area dimensions are (2 * step + 1) x (2 * step + 1) */
        /* Thus, the standard grid area is 3 x 3 for a Near Miss and 5 x 5 for a Close Guess */

        /* Generate the starting/lower bound of the grid area around the previous guess, to make the smart guess in */
        /* May be negative in case the previous guess is close to the border(s) of the field */
        lower_bound_row = prev_row - step;
        lower_bound_col = prev_col - step;

        /* Previous guess is close to the border(s) of the field */
        if (lower_bound_row < 0) {
            /* Generate a random number within a smaller grid area - ignoring the area outside the field */
            upper_bound_row = rand.nextInt(2 * step + 1 + lower_bound_row);

            /* Set the the starting/lower bound of the grid area's row to 0 */
            lower_bound_row = 0;
        }
        /* Previous guess is not close to the border(s) of the field */
        else {
            /* Generate a random number within the standard grid area */
            upper_bound_row = rand.nextInt(2 * step + 1);
        }

        /* Previous guess is close to the border(s) of the field */
        if (lower_bound_col < 0) {
            /* Generate a random number within a smaller grid area - ignoring the area outside the field */
            upper_bound_col = rand.nextInt(2 * step + 1 + lower_bound_col);

            /* Set the the starting/lower bound of the grid area's column to 0 */
            lower_bound_col = 0;
        }
        /* Previous guess is not close to the border(s) of the field */
        else {
            /* Generate a random number within the standard grid area */
            upper_bound_col = rand.nextInt(2 * step + 1);
        }

        /* Generate the row and column numbers of the smart guess */
        /* May be greater than 9 in case the previous guess is close to the border(s) of the field */
        digit_1 = lower_bound_row + upper_bound_row;
        digit_2 = lower_bound_col + upper_bound_col;

        /* Check the ending/upper bounds of the of the grid area around the previous guess */
        /* Previous guess is close to the border(s) of the field */
        if (digit_1 > 9) {
            /* Set the the ending/upper bound of the grid area's row to 9 - ignoring the area outside the field */
            digit_1 = 9;
        }

        /* Previous guess is close to the border(s) of the field */
        if (digit_2 > 9) {
            /* Set the the ending/upper bound of the grid area's column to 9 - ignoring the area outside the field */
            digit_2 = 9;
        }

        /* Generate the tag for the smart guess */
        guess = offset + Integer.parseInt("0" + digit_1 + digit_2);

        /* Return the tag of the smart guess */
        return guess;
    }


    /* Function to calculate distance differences between row and column of gopher, and row and column of current guess respectively */
    private int[] getDistance(int gopher_tag, int guess_tag, int offset) {
        /* Integer array to store the row and column differences */
        int[] diff = new int[2];

        /* Calculate distance difference between row of gopher and row of current guess */
        diff[0] = Math.abs((guess_tag - offset) / 10 - gopher_tag / 10);

        /* Calculate distance difference between column of gopher and column of current guess */
        diff[1] = Math.abs((guess_tag - offset) % 10 - gopher_tag % 10);

        /* Return the array of differences */
        return diff;
    }


    /* Callback function for Stop Button to stop the game OR the Back button to go back to MainActivity */
    protected void stopGame() {
        /* Check if the Button is currently the Stop Button */
        if (stop_button.getText().equals(getString(R.string.stop))) {
            /* Set the game done flag to true */
            game_done = true;

            /* Generate messages for both the player threads to stop the game*/
            Message msg1 = Player1Handler.obtainMessage(STOP_GAME);
            Message msg2 = Player2Handler.obtainMessage(STOP_GAME);

            /* Send messages to both the player threads */
            Player1Handler.sendMessage(msg1);
            Player2Handler.sendMessage(msg2);

            /* Set status for Player 1 as Game Stopped */
            player1_text.setText(getString(R.string.p1_stopped));
            player1_text.setTypeface(player1_text.getTypeface(), Typeface.BOLD);

            /* Set status for Player 2 as Game Stopped */
            player2_text.setText(getString(R.string.p2_stopped));
            player2_text.setTypeface(player2_text.getTypeface(), Typeface.BOLD);

            /* Change the Stop button to Back Button */
            stop_button.setText(getString(R.string.back));
        }

        /* Check if the Button is currently the Back Button */
        else {
            /* Go back to MainActivity */
            Intent back = new Intent(GameActivity.this, MainActivity.class);
            startActivity(back);
        }
    }
}