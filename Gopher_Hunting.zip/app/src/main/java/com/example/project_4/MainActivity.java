package com.example.project_4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    protected Button start_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Get the button view by ID */
        start_button = findViewById(R.id.startButton);

        /* Use the button view to set up a listener for the OnClick event */
        start_button.setOnClickListener(v -> startGame());
    }


    /* Callback function for Start Button to go to GameActivity and begin the Gopher Hunting game */
    protected void startGame() {
        Intent start = new Intent(MainActivity.this, GameActivity.class);
        startActivity(start);
    }
}